/**
 * 
 */
package edu.kit.informatik.element;

import java.util.ArrayList;

/**
 * @author malte
 * @version 0.1
 */
public class TorusBoard extends Board {

    /**
     * Elternkonstruktor
     */
    public TorusBoard() {
        super();
    }
    
    /**
     * as this is a torus field positions out of bounds are allowed
     * so to prevent outOfBoundsExceptions this method returns an 
     * in bounds-alias of the input
     * Nach Spezifikation der Aufgabenstellung
     * @param i input
     * @return alias
     */
    private int cut(int i) {
        if (i >= 0)
            return i % 6;
        else
            return 5 - Math.abs(i + 1) % 6; 
    }
    
    @Override
    public void place(int row, int col) {
        placeToken(cut(row), cut(col));
    }
    
    @Override
    protected ArrayList<Token> right(int row, int col) {
        ArrayList<Token> result = new ArrayList<Token>();
        for (int i = 0; i < 4; i++)
            result.add(getGist()[cut(row)][cut(col + i)].getContent());
        return result;
    }
    
    @Override
    protected ArrayList<Token> down(int row, int col) {
        ArrayList<Token> result = new ArrayList<Token>();
        for (int i = 0; i < 4; i++)
            result.add(getGist()[cut(row + i)][cut(col)].getContent());
        return result;
    }

    // up right
    @Override
    protected ArrayList<Token> upr(int row, int col) {
        ArrayList<Token> result = new ArrayList<Token>();
        for (int i = 0; i < 4; i++)
            result.add(getGist()[cut(row - i)][cut(col + i)].getContent());
        return result;
    }
    
    // up down
    @Override
    protected ArrayList<Token> downr(int row, int col) {
        ArrayList<Token> result = new ArrayList<Token>();
        for (int i = 0; i < 4; i++)
            result.add(getGist()[cut(row + i)][cut(col + i)].getContent());
        return result;
    }

}
