/**
 * 
 */
package edu.kit.informatik.element;

/**
 * @author malte
 * @version 0.1
 */
public class Token {
    /**
     * the size of a token
     */
    static enum Size { GROSS, KLEIN }
    /**
     * the color of a token
     */
    static enum Color { WEISS, SCHWARZ }
    /**
     the shape of a token
     */
    static enum Form { ECKIG, ZYLINDERFOERMIG }
    /**
     * the density of a token
     */
    static enum Density { HOHL, MASSIV }
    
    // Objektattribute
    private int id;
    private Size size;
    private Color color;
    private Form form;
    private Density density;
    
    /**
     * Konstuktor
     * @param id id
     * @param size size
     * @param color color
     * @param form form
     * @param density density
     */
    public Token(int id, Color color, Form form, Size size, Density density) {
        this.setId(id);
        this.setSize(size);
        this.setColor(color);
        this.setForm(form);
        this.setDensity(density);
    }
    
    

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof Token))
            return false;
        Token other = (Token) obj;
        if (id != other.id)
            return false;
        return true;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "" + getId();
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }
    /**
     * @return the size
     */
    public Size getSize() {
        return size;
    }
    /**
     * @return the color
     */
    public Color getColor() {
        return color;
    }
    /**
     * @return the form
     */
    public Form getForm() {
        return form;
    }
    /**
     * @return the density
     */
    public Density getDensity() {
        return density;
    }
    /**
     * @param id the id to set
     */
    private void setId(int id) {
        this.id = id;
    }
    /**
     * @param size the size to set
     */
    private void setSize(Size size) {
        this.size = size;
    }
    /**
     * @param color the color to set
     */
    private void setColor(Color color) {
        this.color = color;
    }
    /**
     * @param form the form to set
     */
    private void setForm(Form form) {
        this.form = form;
    }
    /**
     * @param density the density to set
     */
    private void setDensity(Density density) {
        this.density = density;
    }

}
