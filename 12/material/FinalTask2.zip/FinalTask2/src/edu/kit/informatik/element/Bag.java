/**
 * 
 */
package edu.kit.informatik.element;

import java.util.ArrayList;

import edu.kit.informatik.Terminal;
import edu.kit.informatik.element.Token.Color;
import edu.kit.informatik.element.Token.Density;
import edu.kit.informatik.element.Token.Form;
import edu.kit.informatik.element.Token.Size;

/**
 * @author malte
 * @version 0.1
 */
public final class Bag extends ArrayList<Token> {

    /**
     * not needed, suppresses warning
     */
    private static final long serialVersionUID = 1L;
    
    /**
     * Konstruktor
     */
    public Bag() {
        // ein Set an Spielsteinen erzeugen
        this.add(new Token(0, Color.SCHWARZ, Form.ECKIG, Size.KLEIN, Density.HOHL));
        this.add(new Token(1, Color.SCHWARZ, Form.ECKIG, Size.KLEIN, Density.MASSIV));
        this.add(new Token(2, Color.SCHWARZ, Form.ECKIG, Size.GROSS, Density.HOHL));
        this.add(new Token(3, Color.SCHWARZ, Form.ECKIG, Size.GROSS, Density.MASSIV));
        this.add(new Token(4, Color.SCHWARZ, Form.ZYLINDERFOERMIG, Size.KLEIN, Density.HOHL));
        this.add(new Token(5, Color.SCHWARZ, Form.ZYLINDERFOERMIG, Size.KLEIN, Density.MASSIV));
        this.add(new Token(6, Color.SCHWARZ, Form.ZYLINDERFOERMIG, Size.GROSS, Density.HOHL));
        this.add(new Token(7, Color.SCHWARZ, Form.ZYLINDERFOERMIG, Size.GROSS, Density.MASSIV));
        this.add(new Token( 8, Color.WEISS, Form.ECKIG, Size.KLEIN, Density.HOHL));
        this.add(new Token( 9, Color.WEISS, Form.ECKIG, Size.KLEIN, Density.MASSIV));
        this.add(new Token(10, Color.WEISS, Form.ECKIG, Size.GROSS, Density.HOHL));
        this.add(new Token(11, Color.WEISS, Form.ECKIG, Size.GROSS, Density.MASSIV));
        this.add(new Token(12, Color.WEISS, Form.ZYLINDERFOERMIG, Size.KLEIN, Density.HOHL));
        this.add(new Token(13, Color.WEISS, Form.ZYLINDERFOERMIG, Size.KLEIN, Density.MASSIV));
        this.add(new Token(14, Color.WEISS, Form.ZYLINDERFOERMIG, Size.GROSS, Density.HOHL));
        this.add(new Token(15, Color.WEISS, Form.ZYLINDERFOERMIG, Size.GROSS, Density.MASSIV));
    }
    
    /**
     * Druckt alle enthaltenen Spielsteine auf die Kommandozeile
     */
    public void print() {
        String out = "";
        for (Token t : this) {
            out += " " + t;
        }
        Terminal.printLine(out.substring(1));
    }
    
    
    /**
     * Gibt den Index des Tokens mit der ID aus
     * @param id ID des gesuchten Tokens
     * @return Index (-1 if not found)
     */
    public int indexOfId(int id) {
        int index = 0;
        for (Token t : this) {
            if (t.getId() == id)
                return index;
            index++;
        }
        return -1;
    }

}
