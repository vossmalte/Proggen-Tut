/**
 * 
 */
package edu.kit.informatik.element;

/**
 * @author malte
 * @version 0.1
 */
public class Cell {
    private Token content;
    /**
     * 
     */
    public Cell() {
        // nothing todo
    }
    
    /**
     * @return Zelle ist belegt
     */
    public boolean isOccupied() {
        if (getContent() == null)
            return false;
        return true;
    }
    
    /**
     * @return Zelle is leer
     */
    public boolean isEmpty() {
        return !isOccupied();
    }
    
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        String result = isEmpty() ? "#" : getContent().toString();   // Platzhalter wenn leer
        return result;
    }

    /**
     * @return the content
     */
    Token getContent() {
        return content;
    }
    /**
     * @param content the content to set
     */
    void setContent(Token content) {
        this.content = content;
    }

}
