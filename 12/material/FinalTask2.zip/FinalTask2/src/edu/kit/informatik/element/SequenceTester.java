/**
 * 
 */
package edu.kit.informatik.element;

import java.util.ArrayList;

//import edu.kit.informatik.Terminal;

/**
 * @author malte
 * @version 0.1
 */
public final class SequenceTester {

    /**
     * 
     */
    private SequenceTester() {
    }
    
    /**
     * Testet eine Sequenz an Tokens auf gleiche Eigenschaften
     * @param input Liste an Tokens
     * @return Falls die Sequenz eine gemeinsame Eigenschaft hat: true, sonst false
     */
    public static boolean test(ArrayList<Token> input) {
        if (input.contains(null))
            return false;
        Token[] seq = new Token[input.size()];   // bug fix - als array spart man ein paar Zeichen
        input.toArray(seq);
        // war schon als Array implementiert, als Liste war es einfacher den Input zu generieren
        if (seq.length != 4)
            return false;
        
        if (seq[0].getSize() == seq[1].getSize())
            if (seq[1].getSize() == seq[2].getSize())
                if (seq[2].getSize() == seq[3].getSize())
                    return true;
        if (seq[0].getForm() == seq[1].getForm())
            if (seq[1].getForm() == seq[2].getForm())
                if (seq[2].getForm() == seq[3].getForm())
                    return true;
        if (seq[0].getDensity() == seq[1].getDensity())
            if (seq[1].getDensity() == seq[2].getDensity())
                if (seq[2].getDensity() == seq[3].getDensity())
                    return true;
        if (seq[0].getColor() == seq[1].getColor())
            if (seq[1].getColor() == seq[2].getColor())
                if (seq[2].getColor() == seq[3].getColor())
                    return true;
        return false;
        
    }

}
