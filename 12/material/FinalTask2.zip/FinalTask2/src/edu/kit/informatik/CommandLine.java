package edu.kit.informatik;

public class CommandLine {
	
	private CommandLine() {}
	
	/**
     * liest die Eingabe von der Kommandozeile und verarbeitet das Signal
     */
    public static void run() {
    	do {
        String input = Terminal.readLine();
        processCommand(input);
    	} while(true); // programm l�uft so lange, bis es per "quit" beendet wird
    }
    
    /**
     * Verarbeitet Eingaben von der Kommandozeile
     * @param input Eingabe
     */
    public static void processCommand(String input) {
    	String[] args = input.split(" ");
        if (args.length > 2) {      // Dreigeteilter Befehl ex. nicht
            Main.error("invalid arguments.");
            return;
        }
        String[] para = args.length > 1 ? args[1].split(";") : new String[0];
        try {
        switch(args[0]) {       // alle sechs Befehle entgegennehmen und verarbeiten
        case "select":
            if (checkParameterNumber(para.length, 1)) {
                int id = Integer.parseInt(para[0]);
                Main.getBoard().select(id);
            }
            break;
        case "place":
            if (checkParameterNumber(para.length, 2)) {
                int row = Integer.parseInt(para[0]);
                int col = Integer.parseInt(para[1]);
                Main.getBoard().place(row, col);
            }
            else {
                Main.getBoard().undoSelect();
            }
            break;
        case "bag":
            if (checkParameterNumber(para.length, 0)) {
                Main.getBoard().getBag().print();
            }
            break;
        case "rowprint":
            if (checkParameterNumber(para.length, 1)) {
                int row = Integer.parseInt(para[0]);
                Main.getBoard().rowprint(row);
            }
            break;
        case "colprint":
            if (checkParameterNumber(para.length, 1)) {
                int col = Integer.parseInt(para[0]);
                Main.getBoard().colprint(col);
            }
            break;
        case "quit":
            if (checkParameterNumber(para.length, 0))
                System.exit(0);
            break;
        default:
            Main.error("unknown command.");
            break;
        }
        }
        catch (NumberFormatException e) {   // Argument ist keine Zahl...
            Main.error("invalid argument.");
            if (args[0].equals("place"))
                Main.getBoard().undoSelect();
        }
    }
    
    private static boolean checkParameterNumber(int given, int required) {
        if (given == required)
            return true;
        else if (required == 0)
            Main.error("this command does not accept any parameter.");
        else if (required == 1) 
            Main.error("this command requires exactly one parameter.");
        else if (required == 2) 
            Main.error("this command requires exactly two parameters.");
        return false;
    }

}
