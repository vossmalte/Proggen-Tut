/**
 * 
 */
package edu.kit.informatik;


import edu.kit.informatik.element.Board;
import edu.kit.informatik.element.TorusBoard;
/**
 * @author malte
 * @version 0.1
 */
public final class Main {
    private static Board board;
    /**
     * 
     */
    private Main() {
    }
    
    /**
     * Gibt eine Fehlermeldung aus, die mit "Error, " beginnt
     * @param msg Fehlerbeschreibung
     */
    public static void error(String msg) {
        Terminal.printLine("Error, " + msg);
    }
    
    /**
     * 
     * @param given number of given arguments
     * @param required number of required arguments
     * @return true if it matches
     */

    /**
     * @param args Kommandozeilenparameter
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        init(args);
        
        CommandLine.run();            // Kommandozeile abrufen bis das Programm manuell beendet wird
    }
    
    public static void init(String[] args) {
    	String status;              // standard ^ torus
        status = args.length != 0 ? args[0] : "";           // Bugfix für fehlendes Kommandozeilenargument
        if (status.equals("standard"))
            board = new Board();
        else if (status.equals("torus")) 
            board = new TorusBoard();
        else {
            error("invalid configuration.");
            System.exit(1);
        }
    }
    
    
    
    
        
    /**
     * @return the board
     */
    static Board getBoard() {
        return board;
    }
    
}
