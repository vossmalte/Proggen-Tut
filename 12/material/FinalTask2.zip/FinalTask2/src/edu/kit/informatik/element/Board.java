/**
 * 
 */
package edu.kit.informatik.element;

import edu.kit.informatik.Main;
import edu.kit.informatik.Terminal;
import java.util.ArrayList;

/**
 * @author malte
 * @version 0.1
 */
public class Board {
    // Attribute
    private Cell[][] gist;     // Das Wesentliche - 6x6 Felder 
    private Token selected;     // der aktuell ausgewählte Spielstein
    private int numberOfMoves;  // Anzahl der gespielten Züge
    private Bag bag;            // Sack mit Spielsteinen
    private boolean won;
    /**
     * 
     */
    public Board() {
        // TODO Auto-generated constructor stub
        gist = new Cell[6][6];
        for (int i = 0; i < 6; i++)
            for (int j = 0; j < 6; j++)
                gist[i][j] = new Cell();        // jede Zelle initialisieren
        setSelected(null);
        setBag(new Bag());
        setNumberOfMoves(0);
        won = false;
    }
    
    
    /**
     * wählt einen Spielstein mit ID aus
     * @param id ID
     */
    public void select(int id) {
        if (isWon()) {
            Main.error("game over.");
        }
        if (isSelected()) {
            Main.error("a token has already been selected.");
            return;
        }
        int index = getBag().indexOfId(id);
        if (index == -1) {
            Main.error("token not found");
            return;
        }
        Token t = getBag().remove(index);
        setSelected(t);
        Terminal.printLine("OK");
    }
    
    /**
     * legt den ausgewählten Spielstein zurück in den Vorrat
     */
    public void undoSelect() {
        if (isSelected()) {
            getBag().add(getSelected());
            setSelected(null);
        }
    }
    
    /**
     * init place
     * @param row row
     * @param col col
     */
    public void place(int row, int col) {
        if (isInBounds(row) && isInBounds(col)) 
            placeToken(row, col);
        else {
            Main.error("invalid row / column.");    
            undoSelect();
        }
    }
    
    /**
     * setzt einen Spielstein auf das angegebene Feld.
     * Setzt selected auf null;
     * erhöht Zug um eins
     * @param row Zeile
     * @param col Spalte
     */
    protected void placeToken(int row, int col) {
        if (isSelected() && !isWon()) {             // Placebefehlmöglich
            if (gist[row][col].isEmpty()) {
                gist[row][col].setContent(getSelected());
                setSelected(null);
                if (checkWon()) {
                    Terminal.printLine("P" + ((getNumberOfMoves() + 1) % 2 + 1) + " wins");
                    Terminal.printLine("" + getNumberOfMoves());
                    setWon(true);
                }
                else if (getBag().isEmpty()) {
                    Terminal.printLine("draw");
                    setWon(true);
                }
                else {
                    setNumberOfMoves(getNumberOfMoves() + 1);       // Zahl der Züge incrementieren
                    Terminal.printLine("OK");
                }
            }
            else {
                undoSelect();
                Main.error("cell is occupied.");
            }
                
        }
        else
            Main.error("a token has to be selected first / game over.");
    }
    
    /**
     * Nach der Musterlösung zu vier gewinnt
     * @return true falls das Spiel gewonnen wurde
     */
    private boolean checkWon() {
        for (int i = 0; i < 6; i++)
            for (int j = 0; j < 6; j++)
                if (checkCell(i, j))
                    return true;
        return false;
    }
    
    /**
     * @param row Zeile
     * @param col Spalte
     * @return true falls eine Sequenz ausgehend von row, col vier ähnliche
     * Steine beinhaltet
     */
    private boolean checkCell(int row, int col) {
        boolean rig = SequenceTester.test(right(row, col));
        boolean dow = SequenceTester.test(down(row, col));
        boolean uri = SequenceTester.test(upr(row, col));
        boolean udo = SequenceTester.test(downr(row, col));
        return (rig || dow || uri || udo);
        
    }
    
    /**
     * @param row Zeile
     * @param col Spalte
     * @return Liste aus rechten Nachbarn des row, col
     */
    protected ArrayList<Token> right(int row, int col) {
        ArrayList<Token> result = new ArrayList<Token>();
        for (int i = col; i < 6 && i - col < 4; i++)
            result.add(getGist()[row][i].getContent());
        return result;
    }
    
    /**
     * @param row Zeile
     * @param col Spalte
     * @return Liste aus unteren Nachbarn des row, col
     */
    protected ArrayList<Token> down(int row, int col) {
        ArrayList<Token> result = new ArrayList<Token>();
        for (int i = row; i < 6 && i - row < 4; i++)
            result.add(getGist()[i][col].getContent());
        return result;
    }
    
    // up right
    /**
     * @param row Zeile
     * @param col Spalte
     * @return Liste aus right-upper Nachbarn des row, col
     */
    protected ArrayList<Token> upr(int row, int col) {
        ArrayList<Token> result = new ArrayList<Token>();
        int min = Math.min(row, 5 - col);
        for (int i = 0; i < 4 && i <= min; i++)
            result.add(getGist()[row - i][col + i].getContent());
        return result;
    }
    
    // down right
    /**
     * @param row Zeile
     * @param col Spalte
     * @return Liste aus right-down Nachbarn des row, col
     */
    protected ArrayList<Token> downr(int row, int col) {
        ArrayList<Token> result = new ArrayList<Token>();
        int max = 5 - Math.max(row, col);
        for (int i = 0; i < 4 && i <= max; i++)
            result.add(getGist()[row + i][col + i].getContent());
        return result;
    }
    
    /**
     * Druckt eine Zeile des Spielfeldes auf die Kommandozeile
     * @param row Zeile
     */
    public void rowprint(int row) {
        if (!isInBounds(row)) {
            Main.error("invalid argument.");
            return;
        }
        String out = "";
        for (Cell c : getGist()[row])
            out += " " + c;
        Terminal.printLine(out.substring(1));
    }
    
    /**
     * Druckt eine Spalte des Spielfeldes auf die Kommandozeile
     * @param col Spalte
     */
    public void colprint(int col) {
        if (!isInBounds(col)) {
            Main.error("invalid argument.");
            return;
        }
        String out = "";
        for (Cell[] row : getGist())
            out += " " + row[col];
        Terminal.printLine(out.substring(1));
    }
    
    /**
     * Ist die angegebene Zeile / Spalte gültig?
     * @param rowcol Zeile / Spalte
     * @return gültig?
     */
    public boolean isInBounds(int rowcol) {
        if (rowcol >= 0 && rowcol < 6)
            return true;
        else
            return false;    
    }
    
    /**
     * @return ist z.Z. ein Spielstein ausgewählt?
     */
    public boolean isSelected() {
        if (getSelected() == null)
            return false;
        else 
            return true;
    }
    
    /**
     * @return the gist
     */
    protected Cell[][] getGist() {
        return gist;
    }



    /**
     * @return the numberOfMoves
     */
    int getNumberOfMoves() {
        return numberOfMoves;
    }


    /**
     * @param numberOfMoves the numberOfMoves to set
     */
    void setNumberOfMoves(int numberOfMoves) {
        this.numberOfMoves = numberOfMoves;
    }


    /**
     * @return the selected
     */
    private Token getSelected() {
        return selected;
    }


    /**
     * @param selected the selected to set
     */
    private void setSelected(Token selected) {
        this.selected = selected;
    }


    /**
     * @return the bag
     */
    public Bag getBag() {
        return bag;
    }

    /**
     * @param bag the bag to set
     */
    private void setBag(Bag bag) {
        this.bag = bag;
    }

    /**
     * @return the won
     */
    private boolean isWon() {
        return won;
    }


    /**
     * @param won the won to set
     */
    private void setWon(boolean won) {
        this.won = won;
    }

    /*
     * nicht mehr benötigt
    public void print() {
        for (Cell[] row : gist) {
        String out = "";
            for (Cell c : row) {
                out += " " + c;
            }
            Terminal.printLine(out.substring(1));
        }
    }
    */
    

}
