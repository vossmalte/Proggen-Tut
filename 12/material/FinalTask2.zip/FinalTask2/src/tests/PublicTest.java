package tests;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import edu.kit.informatik.CommandLine;
import edu.kit.informatik.Main;
import edu.kit.informatik.Terminal;

public class PublicTest {
	
	ArrayList<String> output = Terminal.outputStack;

	@Before
	public void setUp() throws Exception {
		output.clear();
		String[] args = {"torus"};
		Main.init(args);
	}

	@Test
	public void testMain() {
		String[] in = {
				"select 11",
				"place 1;4",
				"select 7",
				"place 3;0",
				"select 5",
				"place 4;1",
				"select 15",
				"place 2;5",
				"rowprint 4"
		};
		String[] out = {
				"OK",
				"OK",
				"OK",
				"OK",
				"OK",
				"OK",
				"OK",
				"P1 wins",
				"3",
				"# 5 # # # #"				
		};
		
		for(String input : in) {   // run
			System.out.println("> " + input);
			CommandLine.processCommand(input);
		}
		
		// test
		assertArrayEquals(out, Terminal.outputStack.toArray());
	}

}
